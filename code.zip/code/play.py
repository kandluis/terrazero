from simulation import game_runner

if __name__ == '__main__':
  runner = game_runner.GameRunner()
  runner.execute()
