import os


class UnimplementedError(Exception):
  pass


class InternalError(Exception):
  pass
